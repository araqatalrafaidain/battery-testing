document.addEventListener('DOMContentLoaded', function () {
  var form = document.querySelector('.booking-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = form.querySelector('input[type="text"]').value.trim();
      alert('Thanks' + (name ? ', ' + name : '') + '! We received your request and will call you shortly.');
      form.reset();
    });
  }
});
